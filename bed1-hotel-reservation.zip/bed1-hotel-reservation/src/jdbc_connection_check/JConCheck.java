package jdbc_connection_check;

import java.sql.*;  

public class JConCheck{  
	
	public boolean db_con_check() {
		
		boolean flag = true;
		
		try{  
			Class.forName("com.mysql.cj.jdbc.Driver");  
			
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/my_first_db?useSSL=false&amp","root","m17br4jn9z");  
			
			con.close();  
			
		}catch(Exception e){ 
			//System.out.println(e);
			
			flag = false;
			
		}
		
		return flag;
			
	}
	
	
	public static void main(String args[]){  
		
		try{  
			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
					"jdbc:mysql://localhost:3306/my_first_db?useSSL=false&amp","root","m17br4jn9z");  
			
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select * from persons");  
			
			while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3) + " " + rs.getString(4) + " " + rs.getString(5));
			
			con.close();  
			
		}catch(Exception e){ 
			System.out.println(e);
		}  
	}  
}