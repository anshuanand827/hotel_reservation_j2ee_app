package com.wipro.bed1;

import java.io.PrintWriter;
import java.util.List;

import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import entity.BookingEntity;
import entity.HotelEntity;
import jdbc_connection_check.JConCheck;
import price_range.PriceGST;
import price_range.Total;

public class DataProcessing {

	List<HotelEntity> retreived_dataset;
	
	public String hotel_name;
	public String city;
	public String booked_date;
	
	public boolean check_db_con() {

		return new JConCheck().db_con_check();

	}


	public boolean check_availability(String city, String hotel, String date){

		boolean flag = false;

		Session session = new HibernateUtil().getSessionForHotelInfo().getCurrentSession();
		
		try {

			session.beginTransaction();

			List<HotelEntity> record_list = session.createQuery("from HotelEntity where city = '" + city + "' and hotel_name = '" + hotel +"'").getResultList();

			retreived_dataset = record_list;

			//System.out.println("Size of record list : " + record_list.size());

			if(record_list.size() < 1) { 
				flag =  false;
			}else 			
				for(HotelEntity temp_obj : record_list) 					
					if(temp_obj.getBooked_date().equals(date)) 
						flag = true;
					else {
						
						flag = false;
						
//						this.city = city;
//						this.hotel_name = hotel;
//						this.booked_date = date;
						
					}
			
					
			session.getTransaction().commit();

		}catch(Exception e){

			e.printStackTrace();
			System.out.println("Bad Query!");

			flag = false;

		}finally {

			session.close();
		}

		return flag;
	}


	public void generateHotelAvailalabilityPage(PrintWriter write) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		
		PriceGST single_bdr_obj = (PriceGST)context.getBean("single");
		PriceGST double_bdr_obj = (PriceGST)context.getBean("double");
		PriceGST triple_bdr_obj = (PriceGST)context.getBean("triple");
		PriceGST quad_bdr_obj = (PriceGST)context.getBean("quad");
		PriceGST king_bdr_obj = (PriceGST)context.getBean("king");
		PriceGST suite_bdr_obj = (PriceGST)context.getBean("suite");
		
		Total call = new Total();

		write.println("<!DOCTYPE>");
		write.println("<html>");
		write.println("<head>");
		write.println("<title>Available Rooms</title>");
		write.println("<style>");
		write.println("table, td, th{ border : 1px solid black;}");
		write.println("</style>");
		write.println("</head>");
		write.println("<body>");
		write.println("<h1>Available Rooms</h1>");
		write.println("<div id='table_data' style='margin-bottom:20px;'>");
		write.println("<table style='width:100%; border-collapse:collapse;'>");
		write.println("<tr>");
		write.println("<th>Room Type</th>");
		write.println("<th>Price</th>");
		write.println("<th>GST %</th>");
		write.println("<th>Total</th>");
		write.println("</tr>");
		
		//for(HotelEntity temp : retreived_dataset) {
			 
			  write.println("<tr>");
			  write.println("<td>Single Bedroom </td>");
			  write.println("<td>" +single_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+single_bdr_obj.getGst()+"%</td>");
			  write.println("<td>"+call.calculate_total_price("single")+"</td>");
			  write.println("</tr>");
			  
			  write.println("<tr>");
			  write.println("<td>Double Bedroom </td>");
			  write.println("<td>" +double_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+double_bdr_obj.getGst()+"%</td>");
			  write.println("<td>"+call.calculate_total_price("double")+"</td>");
			  write.println("</tr>");
			  
			  write.println("<tr>");
			  write.println("<td>Triple Bedroom</td>");
			  write.println("<td>" +triple_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+triple_bdr_obj.getGst()+"%</td>");
			  write.println("<td>"+call.calculate_total_price("triple")+"</td>");
			  write.println("</tr>");
			  
			  write.println("<tr>");
			  write.println("<td>Quad Bedroom</td>");
			  write.println("<td>" +quad_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+quad_bdr_obj.getGst()+"</td>");
			  write.println("<td>"+call.calculate_total_price("quad")+"</td>");
			  write.println("</tr>");

			  write.println("<tr>");
			  write.println("<td>King Size</td>");
			  write.println("<td>" +king_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+king_bdr_obj.getGst()+"%</td>");
			  write.println("<td>"+call.calculate_total_price("king")+"</td>");
			  write.println("</tr>");
			  
			  write.println("<tr>");
			  write.println("<td>Executive Suite</td>");
			  write.println("<td>" +suite_bdr_obj.getPrice() +"</td>");
			  write.println("<td>"+suite_bdr_obj.getGst()+"%</td>");
			  write.println("<td>"+call.calculate_total_price("suite")+"</td>");
			  write.println("</tr>");		  
			  
		//}

		write.println("</table>");
		write.println("</div>");
		write.println("<a href='ReservationPage.html'><input type='button' value='Confirm' id='confirm'></a>");
		write.println("<a href='index.html'><input type='button' value='Go back' id='back'>");

		write.println("</body>");
		write.println("</html>");

	}

	
	public void save_record(String gname, int age, String gender, String email, String mobile, String room_type, String resvn_date){
		
		Session session = new HibernateUtil().getSessionForBookingInfo().getCurrentSession();
		
		try {
			
			session.beginTransaction();
			
			BookingEntity book = new BookingEntity();
			book.setAge(age);
			book.setEmail(email);
			book.setGender(gender);
			book.setName(gname);
			book.setRdate(resvn_date);
			book.setMobile(mobile);
			
			session.save(book);
			
		}catch(Exception e) {
			
			e.printStackTrace();
			
			System.out.println("\nSomething happened!\n");
			
		}finally {
			session.close();
			
		}
		
		
		
	}

	public void update_hotel_db(String city, String hname, String date_booked) {
		
		Session session = new HibernateUtil().getSessionForHotelInfo().getCurrentSession();
	
		try {
			
			session.beginTransaction();
			
			HotelEntity call = new HotelEntity();
			
			call.setCity(city);
			call.setBooked_date(date_booked);
			call.setHotel_name(hname);
			
			session.saveOrUpdate(call);
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		
	}
	
}
