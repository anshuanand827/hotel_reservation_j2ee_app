package com.wipro.bed1;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Test")
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
		
	}
	
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		String city_input = request.getParameter("city");
		String hotel_input = request.getParameter("hotel");
		String date_input = request.getParameter("date");
		
		PrintWriter write = response.getWriter();

		DataProcessing call = new DataProcessing();
		
		if(call.check_db_con()) {
			
			if(call.check_availability(city_input, hotel_input, date_input)) {
				write.println("Apologies! No room is available on " + date_input + "\nPlease check for another date..");
			}
			else {
				call.generateHotelAvailalabilityPage(write);
				call.update_hotel_db(city_input, hotel_input, date_input);
			}
			
		}else {
			write.println("Aww snap! \nServer is down!");
		}
		
		
		write.close();
		
	}

}
