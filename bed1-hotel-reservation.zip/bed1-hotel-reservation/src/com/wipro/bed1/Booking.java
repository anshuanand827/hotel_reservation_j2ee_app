package com.wipro.bed1;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Booking")
public class Booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Booking() {
        
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		String gname = request.getParameter("gname");
		int age = Integer.parseInt(request.getParameter("age"));
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String room_type = request.getParameter("roomtype");
		String rdate = request.getParameter("rdate");
		
		PrintWriter write = response.getWriter();
		write.println("<h1>Thank you for chosing us!</h1>");
		
		DataProcessing call = new DataProcessing();
		
		if(call.check_db_con()) { 			
			call.save_record(gname, age, gender, email, mobile, room_type, rdate);
		}
		else			
			System.out.println("Server is down! Please try after some time");

	}

}
