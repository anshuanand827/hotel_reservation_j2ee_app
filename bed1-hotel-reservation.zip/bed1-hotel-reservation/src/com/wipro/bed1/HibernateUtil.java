package com.wipro.bed1;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.BookingEntity;
import entity.HotelEntity;

public class HibernateUtil {

	public SessionFactory getSessionForHotelInfo() {
		
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(HotelEntity.class)
				.buildSessionFactory();

		
		return factory;
		
	}
	
	public SessionFactory getSessionForBookingInfo() {
		
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(BookingEntity.class)
				.buildSessionFactory();

		
		return factory;
		
	}
	
}
