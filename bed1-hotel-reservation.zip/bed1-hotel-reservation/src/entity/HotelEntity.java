package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="hotel_db")
public class HotelEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hotel_id")
	private int hotel_id;

	@Column(name="city")
	private String city;

	@Column(name="hotel_name")
	private String hotel_name;

	@Column(name="booked_date")
	private String booked_date;
		

	public HotelEntity() {
		
	}

	public HotelEntity(String city, String hotel_name, String booked_date) {
		this.hotel_name = hotel_name;
		this.city = city;
		this.booked_date = booked_date;
	}

	public String getBooked_date() {
		return booked_date;
	}

	public void setBooked_date(String booked_date) {
		this.booked_date = booked_date;
	}

	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotel_name() {
		return hotel_name;
	}

	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}

	@Override
	public String toString() {
		return "HotelEntity [hotel_id=" + hotel_id + ", city=" + city + ", hotel_name=" + hotel_name + ", booked_date="
				+ booked_date + "]";
	}
		

}
