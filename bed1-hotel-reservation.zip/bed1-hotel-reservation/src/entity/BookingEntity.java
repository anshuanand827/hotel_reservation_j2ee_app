package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="reservation")
public class BookingEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="booking_id")
	private int booking_id;

	@Column(name="name")
	private String name;

	@Column(name="age")
	private int age;

	@Column(name="gender")
	private String gender;
	
	@Column(name="room_type")
	private String room_type;

	@Column(name="rdate")
	private String rdate;

	@Column(name="email")
	private String email;

	@Column(name="mobile")
	private String mobile;

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRoom_type() {
		return room_type;
	}

	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}

	public String getRdate() {
		return rdate;
	}

	public void setRdate(String rdate) {
		this.rdate = rdate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	@Override
	public String toString() {
		return "BookingEntity [booking_id=" + booking_id + ", name=" + name + ", age=" + age + ", gender=" + gender
				+ ", room_type=" + room_type + ", rdate=" + rdate + ", email=" + email + ", mobile=" + mobile + "]";
	}
	
}
