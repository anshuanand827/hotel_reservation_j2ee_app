package price_range;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Total {
	
	public int calculate_total_price(String room_type) {
		
		float price_val;
		float gst_percent_val;
		
		int total;
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
		
		if(room_type.equals("single")) {
			PriceGST single_bdr_obj = (PriceGST)context.getBean("single");
			price_val = single_bdr_obj.getPrice();
			gst_percent_val = single_bdr_obj.getGst();
		}
		else if(room_type.equals("double")) {
			PriceGST double_bdr_obj = (PriceGST)context.getBean("double");
			price_val = double_bdr_obj.getPrice();
			gst_percent_val = double_bdr_obj.getGst();
		}
		else if(room_type.equals("triple")) {
			PriceGST triple_bdr_obj = (PriceGST)context.getBean("triple");
			price_val = triple_bdr_obj.getPrice();
			gst_percent_val = triple_bdr_obj.getGst();
		}
		else if(room_type.equals("quad")) {
			PriceGST quad_bdr_obj = (PriceGST)context.getBean("quad");
			price_val = quad_bdr_obj.getPrice();
			gst_percent_val = quad_bdr_obj.getGst();
		}
		else if(room_type.equals("king")) {
			PriceGST king_bdr_obj = (PriceGST)context.getBean("king");
			price_val = king_bdr_obj.getPrice();
			gst_percent_val = king_bdr_obj.getGst();
		}
		else {
			PriceGST suite_bdr_obj = (PriceGST)context.getBean("suite");
			price_val = suite_bdr_obj.getPrice();
			gst_percent_val = suite_bdr_obj.getGst();
		}
		
		total = (int ) (price_val + price_val*gst_percent_val/100);
		
		return total;
		
	}
	
	public static void main(String args[]) {
		
		System.out.println(new Total().calculate_total_price("suite"));
				
	}
	
}
