package price_range;

public class PriceGST {
	
	private float price;
	private float gst;
	
	public PriceGST() {
		
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	
	@Override
	public String toString() {
		return "PriceGST [price=" + price + ", gst=" + gst + "]";
	}
	
}
